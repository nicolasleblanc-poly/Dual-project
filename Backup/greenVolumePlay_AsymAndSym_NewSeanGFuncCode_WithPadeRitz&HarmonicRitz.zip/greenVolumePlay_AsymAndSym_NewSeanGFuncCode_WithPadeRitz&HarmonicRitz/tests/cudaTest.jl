
# FOR later, CUDA initialization
# cudaLibPtr = libInitCu!()
# devNum = devCount(cudaLibPtr)
# print("Found ", devNum, " devices.\n")
# libFinlCu!(cudaLibPtr)